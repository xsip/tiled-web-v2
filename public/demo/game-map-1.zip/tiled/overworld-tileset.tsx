<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="overworld-tileset" tilewidth="16" tileheight="16" tilecount="1440" columns="40">
 <image source="../tiles/Overworld.png" width="640" height="576"/>
</tileset>
