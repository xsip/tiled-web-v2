<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="water-collision" tilewidth="16" tileheight="16" tilecount="196" columns="14">
 <image source="../tiles/water-collision.png" width="225" height="225"/>
</tileset>
