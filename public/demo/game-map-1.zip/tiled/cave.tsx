<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="cave" tilewidth="16" tileheight="16" tilecount="1000" columns="40">
 <image source="../tiles/cave.png" width="640" height="400"/>
</tileset>
